from name import Name
class Supplier(Name):

    def __init(self,name,address,contact_info):
        super().__init__(name,address,contact_info)
    
    def __str__(self):

        return super().__str__() 
