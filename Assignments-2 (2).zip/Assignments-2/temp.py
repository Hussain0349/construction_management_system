class Employ:
    def __init__(self,name,salary):
        super().__init__(name)
        self.salary = salary
class Employ:
    def __init__(self,name,grade):
        super().__init__name()
        self.salary = salary