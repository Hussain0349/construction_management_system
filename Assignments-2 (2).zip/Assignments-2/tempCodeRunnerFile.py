db = DBMS()
db.add_data('John', 'Cement', 100, 500, 'Raw Material', 'ABC Suppliers', 'XYZ Builders')
